from flask import Flask,render_template, redirect, url_for, session
from flask_wtf import FlaskForm
from wtforms import TextField, SubmitField
from wtforms.validators import NumberRange
from joblib import dump, load


app = Flask(__name__)

app.config['SECRET_KEY'] = 'Aloha'

class HeartForm(FlaskForm):
    age = TextField("Age")
    sex = TextField("Sex")
    cp = TextField("Chest Pain")
    trestbps = TextField("Blood Pressure")
    chol = TextField("Cholestoral")
    fbs = TextField("Blood Sugar")
    restecg = TextField("Electrocardiographic")
    thalach = TextField("Heart Rate")
    exang = TextField("Exercise Induced")
    oldpeak = TextField("ST Depression")
    slope = TextField("Peak Exercise")
    ca = TextField("Major Vessels")
    thal = TextField("Thal")


    submit = SubmitField('Analyze')


@app.route('/', methods = ['POST', 'GET'])
def index():

    # Create instance of the Form
    form = HeartForm()

    #if the form is valis on submission(we'll talk about validation next)
    if form.validate_on_submit():
        # Grab the data from the breed on the form.

        session['age'] = form.age.data
        session['sex'] = form.sex.data
        session['cp'] = form.cp.data
        session['trestbps'] = form.trestbps.data
        session['chol'] = form.chol.data
        session['fbs'] = form.fbs.data
        session['restecg'] = form.restecg.data
        session['thalach'] = form.thalach.data
        session['exang'] = form.exang.data
        session['oldpeak'] = form.oldpeak.data
        session['slope'] = form.slope.data
        session['ca'] = form.ca.data
        session['thal'] = form.thal.data
        print(form.age.data)
        print(form.sex.data)
        print(form.cp.data)
        print(form.trestbps.data)
        print(form.chol.data)
        print(form.fbs.data)
        print(form.restecg.data)
        print(form.thalach.data)
        print(form.exang.data)
        print(form.oldpeak.data)
        print(form.slope.data)
        print(form.ca.data)
        print(form.thal.data)

        return redirect(url_for('prediction'))

    return render_template('Hearthome.html', form = form)

#3 Add the return_prediction()

@app.route('/prediction')
def prediction():

    content = {}
    content['Age']=(session['age'])
    content['Sex'] =(session['sex'])
    content['Chest Pain'] =(session['cp'])
    content['Blood Pressure'] =(session['trestbps'])
    content['Cholestoral'] =(session['chol'])
    content['Blood Sugar'] =(session['fbs'])
    content['Electrocardiographic'] =(session['restecg'])
    content['Heart Rate'] =(session['thalach'])
    content['Exercise Induced'] =(session['exang'])
    content['ST Depression'] =(session['oldpeak'])
    content['Peak Exercise'] =(session['slope'])
    content['Major Vessels'] =(session['ca'])
    content['Thal'] =(session['thal'])

    results = return_prediction(model= final_Heart_model,scaler=Heart_scaler, sample_json= content )
    if int(results)== 1: 
        results ='The patient is likely to have heart disease'
    else: 
        results ='The patient is not likely to have heart disease' 
    print(results)
    return render_template('Heartprediction.html',results =results)

def sex(Sex):
    if Sex == 'Male':
        return [1]
    elif Sex == 'Female':
        return [0]   

def cp(ChestPain):
    if Chest_Pain =='asymptomatic':
        return [0]
    elif Chest_Pain =='atypical angina':
        return [1]
    elif Chest_Pain =='non-anginal pain':
        return [2]
    elif Chest_Pain =='typical angina':
        return [3]

def return_prediction(model, scaler, sample_json):
    
    # For larger data features, you should probably write a for-loop
    # That builds out this array for you
    
    age = sample_json['Age']
    sex = sample_json['Sex']
    cp = sample_json['Chest Pain']
    trestbps = sample_json['Blood Pressure']
    chol = sample_json['Cholestoral']
    fbs = sample_json['Blood Sugar']
    restecg = sample_json['Electrocardiographic']
    thalach = sample_json['Heart Rate']
    exang = sample_json['Exercise Induced']
    oldpeak = sample_json['ST Depression']
    slope = sample_json['Peak Exercise']
    ca = sample_json['Major Vessels']
    thal = sample_json['Thal']
    
    Heart = [[age,sex,cp,trestbps,chol,fbs,restecg,thalach,exang,oldpeak,slope,ca,thal]]
    
    Heart = scaler.transform(Heart)
    
    #classes = np.array(['setosa', 'versicolor', 'virginica'])
    
    prediction = model.predict(Heart)
    
    return prediction[0]

#1 Load the Model
#2 Load the Scaler

final_Heart_model = load('Heart_model.h5')
Heart_scaler = load('heart_scaler.pkl')


if __name__ == '__main__':
    app.run()